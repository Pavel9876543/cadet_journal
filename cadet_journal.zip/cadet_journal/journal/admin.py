
from django.contrib import admin
from .models import *

admin.site.register(Group)
admin.site.register(Cadet)
admin.site.register(Teacher)
admin.site.register(Subject)
admin.site.register(Grade)
